# Condi Botnet Source Code V9

# Features updates
```
- Have new methods (TCPSOCKET, TCPWRA, TCPSTREAM, HTTPFLOOD).
- New hidden process function with optimized and better.
- New Anti Debug function.
- Remove other shit and optimized source code.
```

# Contact
```
@az369za (telegram)
```